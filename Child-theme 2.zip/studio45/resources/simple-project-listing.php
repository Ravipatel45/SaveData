<?php
/*
Template Name: Simple Project Listing
**/
remove_action('genesis_loop', 'genesis_do_loop');
// add_action('genesis_after_header', 'include_page');
function include_page() {
    $options = get_option( 'theme_sqt' );
    $blog_image = $options['blog_image'];
    ?>
    <div class="featured_image_area" style="background:url('<?= $blog_image; ?>');">
        <div class="header-title-outer">
          <div class="header-title">
            <div class="h1 entry-title" itemprop="headline">Blogs</div>
          </div>
        </div>
    </div>
<?php
}
add_action('genesis_loop', 'my_custom_loop');
function my_custom_loop() {
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $query_args = array('post_type' => 'project', 'posts_per_page' => 5, 'paged' => $paged, );
    $the_query = new WP_Query($query_args);
    if ($the_query->have_posts()) :
       $acount = 1;
       while ($the_query->have_posts()) : $the_query->the_post(); 
          $content = get_the_content();
          $content = preg_replace("/<img[^>]+\>/i", "", $content);          
          $content = apply_filters('the_content', $content);
          $content = str_replace(']]>', ']]>', $content);
          $content = apply_filters('the_content', $content);
          $content = wp_filter_nohtml_kses($content);
          $short_content = (strlen($content) > 80)?substr($content,0,80):$content; 
          $post_title = get_the_title(); 
          $post_title = (strlen($post_title) > 32)?substr($post_title,0,32)."...":$post_title; 
          $post_image_title = get_the_title(); 
          
          $feat_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
          $image_url = $feat_image[0];
          
          if($image_url == "")
            $image_url = get_stylesheet_directory_uri()."/images/placeholder-blog.png";


          if($acount != 1){
            $image_url = bfi_thumb($image_url, array('width' => 300, 'height' => 200, 'crop' => true ));
          }
          else{
            $image_url = bfi_thumb($image_url, array('width' => 600, 'height' => 300, 'crop' => true ));
          }
        ?>
        <div class="news-item col-md-4"> 
            <div class="single-post-blog"> 
                 <div class="row">                      
					<div class="image-outer">
						<a href="<?= get_permalink(); ?>" title="<?= get_the_title(); ?>"><img class="blog-image" src="<?php echo $image_url; ?>" title="<?php echo ucfirst(strtolower($post_image_title)); ?>" alt="<?php echo ucfirst(strtolower($post_image_title)); ?>"></a>
					</div>
                    <div class="blog-header">
						<div class="blog-title"><a href="<?= get_permalink(); ?>" title="<?= get_the_title(); ?>"><?php echo ucfirst(strtolower($post_title)); ?></a></div>
						<div class="blog-detail">
							<div class="detail-date"><?php echo get_the_date('j M Y'); ?></div>
						</div>
					</div> 
					<div class="blog-content">
						<?php echo $short_content; ?>   
					</div>
                </div>
            </div>
        </div>
       <?php $acount++; endwhile; ?>
        
        <?php if (function_exists("pagination")) {
                pagination($the_query->max_num_pages);}  ?>
        <?php wp_reset_postdata(); ?>

     <?php else: ?>
        <p class="no-post-data"><?php _e('Sorry, no posts matched your criteria.'); ?></p>
    <?php
    endif;
}
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );

genesis();