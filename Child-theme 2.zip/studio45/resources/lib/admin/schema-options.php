<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Register the plugin options
 */
function studio45_schema_settings() {
	register_setting( 'studio45_group', 'studio45' );
}
add_action( 'admin_init', 'studio45_schema_settings' );
/**
 * Register the settings page
 */
function studio45_schema_options() {
	add_theme_page( __( 'Schema options' ), __( 'Schema options' ), 'edit_theme_options', 'studio45_schema_option', 'studio45_schema_page' );
}
add_action( 'admin_menu', 'studio45_schema_options' );
/**
 * Render the settings page
*/
function studio45_schema_page(){
	$options = get_option( 'studio45' ); ?>
	<style>form.options_form {background: #FFF; padding: 10px 15px;} .form-table td {padding: 10px 10px;}</style>
	<div class="wrap">
		<h2 style="margin-bottom:20px;"><?php _e('@Studio45 Schema Settings'); ?></h2>
		<i>This options won't enable untill you fill all the fields of particular group.</i>

		<script type="application/ld+json">{ "@context":"https://schema.org", "@type":"PostalAddress", "name":"Oak Construction Services", "streetAddress":"41 Myrtle Street", "addressLocality":"Glen Waverley", "addressRegion":"VIC", "postalCode":"3150", "addressCountry":"Australia", "telephone":"0433 275 237", "email":"info@oakcs.com.au"}</script>8

		<script type="application/ld+json">{ "@context":"https://schema.org/", "@type":"Map", "url":"https://goo.gl/maps/hUBjkFH8vmo"}</script>1

		<script type="application/ld+json">{ "@context":"https://schema.org", "@type":"LocalBusiness", "image":[ "https://oakcs.com.au/wp-content/uploads/2018/10/download-copy1.png" ], "name":"Oak Construction Services", "address":{ "@type":"PostalAddress", "streetAddress":"41 Myrtle Street", "addressLocality":"Glen Waverley", "addressRegion":"VIC", "postalCode":"3150", "addressCountry":"Australia" }, "priceRange":"Contact Us", "geo":{ "@type":"GeoCoordinates", "latitude": -37.8853397, "longitude": 145.1572243 }, "url":"https://oakcs.com.au", "telephone":"+0433 275 237", "email":"info@oakcs.com.au"}</script>15

		<script type="application/ld+json">{ "@context":"https://schema.org", "@type":"Organization", "name":"Oak Construction Services", "url":"https://oakcs.com.au", "image":"https://oakcs.com.au/wp-content/uploads/2018/10/download-copy1.png" }</script>3

		<script type="application/ld+json">{ "@context":"https://schema.org/", "@type":"Service", "name":"CONSTRUCTION SERVICES", "image":"https://oakcs.com.au/wp-content/uploads/2018/10/construction.jpg", "url":"https://oakcs.com.au/construction-labour-hire-melbourne/", "deascription":"From site inspections, engineered plans, council and VicRoads permits, to the implementation of a safe site."}</script>4

		<script type="application/ld+json">{ "@context":"https://schema.org/", "@type":"Service", "name":"TRAFFIC CONTROL", "image":"https://oakcs.com.au/wp-content/uploads/2018/10/construction-1.jpg", "url":"https://oakcs.com.au/traffic-control-melbourne/", "description":"We tailor our traffic management solutions to the needs of all clients whilst never compromising on safety."}</script>4

		<script type="application/ld+json">{ "@context":"https://schema.org/", "@type":"Service", "name":"LABOUR ", "image":"https://oakcs.com.au/wp-content/uploads/2018/10/construction.jpg", "url":"https://oakcs.com.au/labour-hire-recruitment-agency-melbourne/", "description":"Our experienced staff are committed to providing you with the right people to deliver the project results you need."}</script>4


		<form method="post" action="options.php" class="options_form">
			<?php settings_fields( 'studio45_group' ); ?>
			<table class="form-table">
				<tr>
					<th colspan="2" style="padding: 0px 10px 0px 0;"><h3>Business Basic Information</h3></th>
				</tr>
				<tr valign="top">
					<th scop="row">
						<label for="studio45[business_name]"><?php _e( 'Business Name' ); ?></label>
					</th>
					<td>
						<input class="regular-text" type="text" id="studio45[business_name]" style="width: 500px;" name="studio45[business_name]" value="<?php if( isset( $options['business_name'] ) ) { echo esc_attr( $options['business_name'] ); } ?>"/
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[web_url]"><?php _e( 'Website URL' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="http://" type="email" id="studio45[web_url]" style="width: 500px;" name="studio45[web_url]" value="<?php if( isset( $options['web_url'] ) ) { echo esc_attr( $options['web_url'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[footer_phone]"><?php _e( 'Footer Phone' ); ?></label>
					</th>
					<td>
						<input class="regular-text" type="text" id="studio45[footer_phone]" style="width: 500px;" name="studio45[footer_phone]" value="<?php if( isset( $options['footer_phone'] ) ) { echo esc_attr( $options['footer_phone'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[footer_email]"><?php _e( 'Footer Email' ); ?></label>
					</th>
					<td>
						<input class="regular-text" type="email" id="studio45[footer_email]" style="width: 500px;" name="studio45[footer_email]" value="<?php if( isset( $options['footer_email'] ) ) { echo esc_attr( $options['footer_email'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th colspan="2" style="padding: 0px 10px 0px 0;"><hr/><h3>MAP Schema</h3></th>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[map_url]"><?php _e( 'Enter MAP URL' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="http://" type="text" id="studio45[map_url]" style="width: 500px;" name="studio45[map_url]" value="<?php if( isset( $options['map_url'] ) ) { echo esc_attr( $options['map_url'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th colspan="2" style="padding: 0px 10px 0px 0;"><hr/><h3>Social Media</h3></th>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[facebook]"><?php _e( 'Facebook' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.facebook.com/" type="text" id="studio45[facebook]" style="width: 500px;" name="studio45[facebook]" value="<?php if( isset( $options['facebook'] ) ) { echo esc_attr( $options['facebook'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[twitter]"><?php _e( 'Twitter' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.twitter.com/" type="text" id="studio45[twitter]" style="width: 500px;" name="studio45[twitter]" value="<?php if( isset( $options['twitter'] ) ) { echo esc_attr( $options['twitter'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[gplus]"><?php _e( 'Google+' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.plus.google.com/" type="text" id="studio45[gplus]" style="width: 500px;" name="studio45[gplus]" value="<?php if( isset( $options['gplus'] ) ) { echo esc_attr( $options['gplus'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[youtube]"><?php _e( 'Youtube' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.youtube.com/" type="text" id="studio45[youtube]" style="width: 500px;" name="studio45[youtube]" value="<?php if( isset( $options['youtube'] ) ) { echo esc_attr( $options['youtube'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[linkedin]"><?php _e( 'Linkedin' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.linkedin.com/" type="text" id="studio45[linkedin]" style="width: 500px;" name="studio45[linkedin]" value="<?php if( isset( $options['linkedin'] ) ) { echo esc_attr( $options['linkedin'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[instagram]"><?php _e( 'Instagram' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.instagram.com/" type="text" id="studio45[instagram]" style="width: 500px;" name="studio45[instagram]" value="<?php if( isset( $options['instagram'] ) ) { echo esc_attr( $options['instagram'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[vimeo]"><?php _e( 'Vimeo' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.vimeo.com/" type="text" id="studio45[vimeo]" style="width: 500px;" name="studio45[vimeo]" value="<?php if( isset( $options['vimeo'] ) ) { echo esc_attr( $options['vimeo'] ); } ?>"/>
					</td>
				</tr>
				<tr>
					<th scop="row">
						<label for="studio45[pinterest]"><?php _e( 'Pinterest' ); ?></label>
					</th>
					<td>
						<input class="regular-text" placeholder="https://www.pinterest.com/" type="text" id="studio45[pinterest]" style="width: 500px;" name="studio45[pinterest]" value="<?php if( isset( $options['pinterest'] ) ) { echo esc_attr( $options['pinterest'] ); } ?>"/>
					</td>
				</tr>
			</table>
			<?php submit_button('Update options &rarr;'); ?>
		</form>
		<div class="metabox-holder">
			<div class="postbox">
				<h3><span><?php _e( 'Export Settings' ); ?></span></h3>
				<div class="inside">
					<p><?php _e( 'Export the plugin settings for this site as a .json file. This allows you to easily import the configuration into another site.' ); ?></p>
					<form method="post">
						<p><input type="hidden" name="studio45_action" value="export_settings" /></p>
						<p>
							<?php wp_nonce_field( 'studio45_export_nonce', 'studio45_export_nonce' ); ?>
							<?php submit_button( __( 'Export' ), 'secondary', 'submit', false ); ?>
						</p>
					</form>
				</div><!-- .inside -->
			</div><!-- .postbox -->
			<div class="postbox">
				<h3><span><?php _e( 'Import Settings' ); ?></span></h3>
				<div class="inside">
					<p><?php _e( 'Import the plugin settings from a .json file. This file can be obtained by exporting the settings on another site using the form above.' ); ?></p>
					<form method="post" enctype="multipart/form-data">
						<p>
							<input type="file" name="import_file" required/>
						</p>
						<p>
							<input type="hidden" name="studio45_action" value="import_settings"/>
							<?php wp_nonce_field( 'studio45_import_nonce', 'studio45_import_nonce' ); ?>
							<?php submit_button( __( 'Import' ), 'secondary', 'submit', false ); ?>
						</p>
					</form>
				</div><!-- .inside -->
			</div><!-- .postbox -->
		</div><!-- .metabox-holder -->
	</div><!--end .wrap-->
	<div style="float: right; margin-right: 23px; font-size: 10px;" title="Theme is designed and developed by Ravi Vadhel">Schema options by RAVI VADHEL</div>
	<?php
}
/**
 * Process a settings export that generates a .json file of the shop settings
 */
function studio45_schema_settings_export() {
	if( empty( $_POST['studio45_action'] ) || 'export_settings' != $_POST['studio45_action'] )
		return;
	if( ! wp_verify_nonce( $_POST['studio45_export_nonce'], 'studio45_export_nonce' ) )
		return;
	if( ! current_user_can( 'manage_options' ) )
		return;
	$settings = get_option( 'studio45' );
	ignore_user_abort( true );
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=studio45-settings-export-' . date( 'd-m-Y h-i-s' ) . '.json' );
	header( "Expires: 0" );
	echo json_encode( $settings );
	exit;
}
add_action( 'admin_init', 'studio45_schema_settings_export' );
/**
 * Process a settings import from a json file
 */
function studio45_schema_settings_import() {
	if( empty( $_POST['studio45_action'] ) || 'import_settings' != $_POST['studio45_action'] )
		return;
	if( ! wp_verify_nonce( $_POST['studio45_import_nonce'], 'studio45_import_nonce' ) )
		return;
	if( ! current_user_can( 'manage_options' ) )
		return;
	if($_FILES['import_file']['name'] != ""){
		$extension = end( explode( '.', $_FILES['import_file']['name'] ) );
		if( $extension != 'json' ) {
			wp_die( __( 'Please upload a valid .json file' ) );
		}
		$import_file = $_FILES['import_file']['tmp_name'];
		if( empty( $import_file ) ) {
			wp_die( __( 'Please upload a file to import' ) );
		}
	}
	// Retrieve the settings from the file and convert the json object to an array.
	$settings = (array) json_decode( file_get_contents( $import_file ) );
	update_option( 'studio45', $settings );
	wp_safe_redirect( admin_url( 'themes.php?page=studio45' ) ); exit;
}
add_action( 'admin_init', 'studio45_schema_settings_import' );