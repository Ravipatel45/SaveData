<?php
@ob_start();
/**
 * Do not edit anything in this file unless you know what you're doing
*/
/***********************Required Plugin ********************/
require_once('plugins/plugins-config.php');
/***********************End Required Plugin ********************/

/********************** Contact form 7 Redirect  *********/
//require_once('lib/contact_form_7_redirect/contact_form_7_redirect.php');
/********************** END Contact form 7 Redirect  *********/ 

use Roots\Sage\Config;
use Roots\Sage\Container;
/**
 * Helper function for prettying up errors
 * @param string $message
 * @param string $subtitle
 * @param string $title
 */
$sage_error = function ($message, $subtitle = '', $title = '') {
    $title = $title ?: __('Sage &rsaquo; Error', 'sage');
    $footer = '<a href="https://roots.io/sage/docs/">roots.io/sage/docs/</a>';
    $message = "<h1>{$title}<br><small>{$subtitle}</small></h1><p>{$message}</p><p>{$footer}</p>";
    wp_die($message, $title);
};
/**
 * Ensure compatible version of PHP is used
 */
if (version_compare('7.1', phpversion(), '>=')) {
    $sage_error(__('You must be using PHP 7.1 or greater.', 'sage'), __('Invalid PHP version', 'sage'));
}
/**
 * Ensure compatible version of WordPress is used
 */
if (version_compare('4.7.0', get_bloginfo('version'), '>=')) {
    $sage_error(__('You must be using WordPress 4.7.0 or greater.', 'sage'), __('Invalid WordPress version', 'sage'));
}
/**
 * Ensure dependencies are loaded
 */
if (!class_exists('Roots\\Sage\\Container')) {
    if (!file_exists($composer = __DIR__.'/../vendor/autoload.php')) {
        $sage_error(
            __('You must run <code>composer install</code> from the Sage directory.', 'sage'),
            __('Autoloader not found.', 'sage')
        );
    }
    require_once $composer;
}
/**
 * Sage required files
 *
 * The mapped array determines the code library included in your theme.
 * Add or remove files to the array as needed. Supports child theme overrides.
 */
array_map(function ($file) use ($sage_error) {
    $file = "../app/{$file}.php";
    if (!locate_template($file, true, true)) {
        $sage_error(sprintf(__('Error locating <code>%s</code> for inclusion.', 'sage'), $file), 'File not found');
    }
}, ['helpers', 'setup', 'filters', 'admin']);
/**
 * Here's what's happening with these hooks:
 * 1. WordPress initially detects theme in themes/sage/resources
 * 2. Upon activation, we tell WordPress that the theme is actually in themes/sage/resources/views
 * 3. When we call get_template_directory() or get_template_directory_uri(), we point it back to themes/sage/resources
 *
 * We do this so that the Template Hierarchy will look in themes/sage/resources/views for core WordPress themes
 * But functions.php, style.css, and index.php are all still located in themes/sage/resources
 *
 * This is not compatible with the WordPress Customizer theme preview prior to theme activation
 *
 * get_template_directory()   -> /srv/www/example.com/current/web/app/themes/sage/resources
 * get_stylesheet_directory() -> /srv/www/example.com/current/web/app/themes/sage/resources
 * locate_template()
 * ├── STYLESHEETPATH         -> /srv/www/example.com/current/web/app/themes/sage/resources/views
 * └── TEMPLATEPATH           -> /srv/www/example.com/current/web/app/themes/sage/resources
 */
array_map('add_filter', ['theme_file_path', 'theme_file_uri', 'parent_theme_file_path', 'parent_theme_file_uri'], array_fill(0, 4, 'dirname'));
Container::getInstance()
    ->bindIf('config', function () {
        return new Config([
            'assets' => require dirname(__DIR__).'/config/assets.php',
            'theme' => require dirname(__DIR__).'/config/theme.php',
            'view' => require dirname(__DIR__).'/config/view.php',
        ]);
    }, true);
/** Start the engine */
require_once( TEMPLATEPATH . '/lib/init.php' );

// Menu Display code start
include_once( CHILD_DIR . '/lib/image-cropping.php' );
require_once( CHILD_DIR . '/lib/admin/theme-options.php' );
require_once( CHILD_DIR . '/lib/admin/schema-options.php' );

include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );
require_once( get_stylesheet_directory() . '/lib/customize.php' );
include_once( get_stylesheet_directory() . '/lib/output.php' );
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form') );
// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );
// Add new image sizes.
add_image_size( 'featured-page', 1140, 400, TRUE );
// Add support for 1-column footer widget area.
add_theme_support( 'genesis-footer-widgets', 1 );
// Add support for footer menu.
add_theme_support( 'genesis-menus', array( 'secondary' => __( 'Before Header Menu', 'altitude-pro' ), 'primary' => __( 'Header Menu', 'altitude-pro' ), 'main-menu' => __( 'Header Main Menu', 'altitude-pro' ), 'footer' => __( 'Footer Menu', 'altitude-pro' ) ) );
// Reposition the primary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
//add_action( 'genesis_header', 'genesis_do_nav', 12 );
// Remove navigation meta box.
add_action( 'genesis_theme_settings_metaboxes', 'altitude_remove_genesis_metaboxes' );
function altitude_remove_genesis_metaboxes( $_genesis_theme_settings_pagehook ) {
    remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main' );
}
// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_header', 'genesis_do_subnav', 5 );
// Remove skip link for primary navigation.
add_filter( 'genesis_skip_links_output', 'altitude_skip_links_output' );
function altitude_skip_links_output( $links ) {
    if ( isset( $links['genesis-nav-primary'] ) ) {
        unset( $links['genesis-nav-primary'] );
    }
    return $links;
}
// Add secondary-nav class if secondary navigation is used.
add_filter( 'body_class', 'altitude_secondary_nav_class' );
function altitude_secondary_nav_class( $classes ) {
    $menu_locations = get_theme_mod( 'nav_menu_locations' );
    if ( ! empty( $menu_locations['secondary'] ) ) {
        $classes[] = 'secondary-nav';
    }
    return $classes;
}
// Hook menu in footer.
add_action( 'genesis_footer', 'altitude_footer_menu', 7 );
function altitude_footer_menu() {
    genesis_nav_menu( array('theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false, 'menu_class' => 'genesis-nav-menu', ) );
}
// Add Attributes for Footer Navigation.
add_filter( 'genesis_attr_nav-footer', 'genesis_attributes_nav' );
// Add support for custom header.
add_theme_support( 'custom-header', array('flex-height'=> true,'width'=>720,'height'=> 152,'header-selector'=>'.site-title','header-text'=>false,));
// Add support for structural wraps.
add_theme_support( 'genesis-structural-wraps', array('header', 'nav', 'subnav', 'footer-widgets', 'footer', ) );

// add_action( 'after_setup_theme', 'altitude_localization_setup' );
// function altitude_localization_setup(){echo "Test";}

add_action('genesis_setup','child_theme_setup', 15);
function child_theme_setup() {
    add_action( 'genesis_header', 'be_nav_menus' );
}

function be_remove_metaboxes( $_genesis_theme_settings_pagehook ) {
    remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main' );
}

function be_nav_menus() {
    echo '<div class="menus"><div class="primary">';
    wp_nav_menu( array( 'menu' => 'Primary' ) );
    echo '</div><!-- .primary --><div class="secondary">';
    wp_nav_menu( array( 'menu' => 'Secondary' ) );
    echo '</div><!-- .secondary --></div><!-- .menus -->';
}

// Remove options
remove_action( 'genesis_site_description', 'genesis_seo_site_description',99 );
add_filter( 'genesis_seo_description','conditional_site_description');

function conditional_site_description($description) {
    if ( !is_front_page() ) :
    remove_action( 'genesis_site_decription', 'genesis_seo_site_description' );
    return $description;
    endif;
}

/**
 * Disable the emoji's
 */
function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );

/**
 * Filter function used to remove the tinymce emoji plugin.
 * 
 * @param array $plugins 
 * @return array Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}

//* Add support for after entry widget
add_theme_support('genesis-after-entry-widget-area');
//* Relocate the post info
remove_action('genesis_entry_header', 'genesis_post_info', 12);
add_action('genesis_entry_header', 'genesis_post_info', 5);
remove_action('wp_head', 'rel_canonical');
function at_remove_dup_canonical_link() {return false;}

add_filter('wpseo_canonical', 'at_remove_dup_canonical_link');

add_filter('genesis_seo_title', 'child_header_title', 10, 3);
function child_header_title($title, $inside, $wrap) {$inside = sprintf('<a href="' . site_url() . '" title="%s">%s</a>', esc_attr(get_bloginfo('name')), get_bloginfo('name')); return sprintf('<%1$s class="site-title">%2$s</%1$s>', $wrap, $inside); }

remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action('genesis_entry_header', 'genesis_entry_header_markup_open', 5);
remove_action('genesis_entry_header', 'genesis_entry_header_markup_close', 15);
remove_action('genesis_entry_header', 'genesis_do_post_title');
remove_action('genesis_entry_header', 'genesis_post_info', 12);
remove_action('genesis_footer', 'genesis_footer_markup_open', 5);
remove_action('genesis_footer', 'genesis_do_footer');
remove_action('genesis_footer', 'genesis_footer_markup_close', 15);

function rw_jquery_updater2()
{
    // jQuery
    // Deregister core jQuery
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery','/wp-content/themes/studio45/resources/assets/scripts/jquery-3.2.1.min.js', false, '3.2.1');

    // jQuery Migrate
    // Deregister core jQuery Migrate
    wp_deregister_script('jquery-migrate');
    wp_enqueue_script('jquery-migrate','/wp-content/themes/studio45/resources/assets/scripts/jquery-migrate-3.0.0.min.js', array('jquery'), '3.0.0'); // require jquery, as loaded above
}
// Front-End
add_action('wp_enqueue_scripts', 'rw_jquery_updater2');
include_once( CHILD_DIR . '/lib/image-cropping.php' );

//===================================  Above are THEME SETTING, please do not touch to it.   =====================================================//

//*********************************************************
//You can write your own customisation code from below.
//*********************************************************

/*-----------------End--------------------------*/
add_filter('genesis_after_header', 'genesis_after_header_inner');
function genesis_after_header_inner() {
    if(!is_front_page() && !is_category()){
        $post_id = get_the_ID();
        $feat_image =  wp_get_attachment_image_src( get_post_thumbnail_id($post_id), 'full' );
        $image_url = $feat_image[0];

        echo '<div class="featured_image_area" style="background:url('.$image_url.');">
                <div class="header-title-outer">
                    <div class="header-title">
                        <div class="h1 entry-title" itemprop="headline">' . get_the_title() . '</div>
                    </div>
                </div>
             </div>';
    }
}

//Footer area code
add_action( 'genesis_footer', 'genesis_do_footer2' );
function genesis_do_footer2(){
?>
<section class="footer">
    <div class="wrap">
        <div class="row">
            <div class="col-md-3">
                <?php dynamic_sidebar('footer1');?>
            </div>
            <div class="col-md-3">
                <?php dynamic_sidebar('footer2');?>
            </div>
            <div class="col-md-3">
                <?php dynamic_sidebar('footer3');?>
            </div>
            <div class="col-md-3">
                <?php dynamic_sidebar('footer4');?>
            </div>
        </div>
    </div>
</section>
<div class="copy-right-foo">
    <?php dynamic_sidebar('copyrights'); ?>
</div>
<?php
}

function remove_menus(){
  // remove_menu_page( 'edit.php' );                   //Posts
  // remove_menu_page( 'upload.php' );                 //Media
  // remove_menu_page( 'edit-comments.php' );          //Comments
  // remove_menu_page( 'themes.php' );                 //Appearance
  // remove_menu_page( 'plugins.php' );                //Plugins
  // remove_menu_page( 'tools.php' );                  //Tools
  // remove_menu_page( 'users.php' );                  //Users
  // remove_menu_page( 'options-general.php' );        //Settings
}
// add_action( 'admin_menu', 'remove_menus' );
define( 'DISALLOW_FILE_EDIT', true );

function pagination($pages = '', $range = 4)
{  
     $showitems = ($range * 2)+1;  
     global $paged;
     if(empty($paged)) $paged = 1;
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }  
     if(1 != $pages)
     {
         echo "<div class='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; First</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a>";
         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
             }
         }
         if ($paged < $pages && $showitems < $pages) echo "<a class='next' href=\"".get_pagenum_link($paged + 1)."\">Next &rsaquo;</a>";  
         /*if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a class='last' href='".get_pagenum_link($pages)." '>Last &raquo;</a>";*/
         echo "</div>\n";
     }
}

add_action('genesis_header','genesis_header_fun');
function genesis_header_fun(){
    $options = get_option( 'studio45' );
    $header_phone = $options['phone'];
    $headerlogo = get_header_image();
    ?>
<div class="mobile-menu-cs">
    <button class="mobile-toggle" aria-expanded="false" aria-pressed="false" id="genesis-mobile-primary"><i
            class="fa fa-bars"></i></button>
    <div class="mobile-hide">
        <div class="mobile-header">
            <div class="title-area">
                <p class="site-title" style="background-image:url('<?php echo $headerlogo; ?>');">
                    <a href="<?php echo home_url(); ?>"
                        title="<?php echo get_bloginfo('name'); ?>"><?php echo get_bloginfo('name'); ?>
                    </a>
                </p>
            </div>
            <div class="close-btn"><i class="fa fa-close"></i></div>
        </div>
        <div class="mobile-menu">
            <?php
    $class = 'menu genesis-mobile-menu menu-primary';
	if ( genesis_superfish_enabled() ) {
		$class .= ' js-superfish';
	}

	wp_nav_menu( array(
		'theme_location' => 'primary',
		'menu_class'     => $class,
    ) );
    ?>
        </div>
    </div>
</div>
<div class="title-area">
    <a href="<?php echo home_url(); ?>" title="<?php echo get_bloginfo('name'); ?>">
        <img class="site-title" src="<?php echo $headerlogo; ?>">
    </a>
</div>
<div class="desktop-header-menu">
    <div class="header-menu">
        <?php
    $class = 'menu genesis-nav-menu menu-primary';
	if ( genesis_superfish_enabled() ) {
		$class .= ' js-superfish';
	}

	wp_nav_menu( array(
		'theme_location' => 'primary',
		'menu_class'     => $class,
    ) );
    ?>
    </div>
    <div class="header-right-outer">
        <div class="header-right-call">
        <a href="tel:<?php echo $header_phone; ?>"><i class="fa fa-phone" aria-hidden="true"></i><?php echo $header_phone; ?></a>
        </div>
    </div>
</div>
<?php
}



/* ----------------------- Create Sidebar For Footer Start -------------------*/

function wpb_widgets_init() {

register_sidebar( array(
    'name' => __( 'Footer One', 'wpb' ),
    'id' => 'footer1',
    'description' => __( '', 'wpb' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
) );
register_sidebar( array(
    'name' => __( 'Footer Two', 'wpb' ),
    'id' => 'footer2',
    'description' => __( '', 'wpb' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
) );
register_sidebar( array(
    'name' => __( 'Footer Three', 'wpb' ),
    'id' => 'footer3',
    'description' => __( '', 'wpb' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
) );
register_sidebar( array(
    'name' => __( 'Footer Four', 'wpb' ),
    'id' => 'footer4',
    'description' => __( '', 'wpb' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
) );
register_sidebar( array(
    'name' => __( 'Copyrights', 'wpb' ),
    'id' => 'copyrights',
    'description' => __( '', 'wpb' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
) );

}
add_action( 'widgets_init', 'wpb_widgets_init' );

add_action('genesis_before_footer','genesis_before_footer_fun');
function genesis_before_footer_fun(){
?>
<!-- //test sample slider -->
<div class="carousel-wrap">
    <div class="owl-carousel">
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
        <div class="item"><img src="http://placehold.it/150x150"></div>
    </div>
</div>
<?php
}

function general_admin_notice(){  
    
    if (!file_exists(ABSPATH."robots.txt")) {   
        echo '<div class="notice notice-error">
                    <p>Please add robots.txt file to noindex your site.</p>
                </div>'; 
    }
}
add_action('admin_notices', 'general_admin_notice');


add_filter( 'init', 'wpse_77233_framework_to_settings', 10, 2 );
function wpse_77233_framework_to_settings()
{
    $bg = get_option('blogdescription');
    if($bg == 'Just another WordPress site'){
        $input = update_option( 'blogdescription', sanitize_text_field('') );
    }
    return $input;
}