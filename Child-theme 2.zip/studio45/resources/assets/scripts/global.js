/**
 * This script adds the jquery effects to the Altitude Pro Theme.
 *
 * @package Altitude\JS
 * @author StudioPress
 * @license GPL-2.0+
 */
jQuery(function($) {
    if ($(document).scrollTop() > 0) {
        $('.site-header').addClass('sticky-header');
    }
    // Add opacity class to site header.
    $(document).on('scroll', function() {
        if ($(document).scrollTop() > 0) {
            $('.site-header').addClass('sticky-header');
        } else {
            $('.site-header').removeClass('sticky-header');
        }
    });
    jQuery(".nospace").keydown(function(event) { if (event.keyCode == 32) { event.preventDefault(); } });
    jQuery(".onlynumber").keydown(function(e) {
        if (jQuery.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) { e.preventDefault(); }
    });
    jQuery(".postcode").keypress(function(e) { if (jQuery(this).val().length >= 4) { jQuery(this).val(jQuery(this).val().slice(0, 4)); return false; } });
    jQuery(".phonenumber").keypress(function(e) {
        if (jQuery(this).val().length >= 12) { jQuery(this).val(jQuery(this).val().slice(0, 12)); return false; }
    });
});

// Mobile menu Js start

jQuery(".mobile-toggle").click(function() {
    jQuery('body').addClass('menu-overlay');
    jQuery(".mobile-hide").slideToggle();
    jQuery(this).hide();
    jQuery(".mobile-hide").addClass('active-menu');
});

jQuery(".mobile-header .close-btn").click(function() {
    jQuery('body').removeClass('menu-overlay');
    jQuery(".mobile-hide").hide();
    jQuery(".mobile-toggle").show();
    jQuery(".mobile-hide").removeClass('active-menu');
});

jQuery(document).mouseup(function(e) {
    var container = jQuery(".mobile-hide"); // YOUR CONTAINER SELECTOR
    var newWindowWidth = jQuery(window).width();
    if (window.outerWidth <= 991) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            &&
            container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
            jQuery('body').removeClass('menu-overlay');
            jQuery(".mobile-hide").hide();
            jQuery(".mobile-toggle").show();
            jQuery(".mobile-hide").removeClass('active-menu');
            jQuery('ul.sub-menu').hide();
            jQuery('li.menu-item-has-children i').removeClass('fa-angle-up');
            jQuery('li.menu-item-has-children i').addClass('fa-angle-down');
        }
    }
});

// Mobile menu Js end

// Mobile menu Dropdown item js start

jQuery(document).ready(function() {
    var newWindowWidth = jQuery(window).width();
    if (window.outerWidth <= 767) {
        //jQuery('li.menu-item-has-children .sf-with-ul').append('<i class="fa fa-angle-down"></i>');
        jQuery('<i class="fa fa-angle-down"></i>').insertBefore("ul.sub-menu");
        jQuery("li.menu-item-has-children i").click(function() {
            //jQuery('ul.sub-menu').not(jQuery(this).closest('li.menu-item-has-children').children('ul.sub-menu')).hide();
            jQuery('li.menu-item-has-children i').not(jQuery(this).parents('li').find('i')).removeClass('fa-angle-up');
            jQuery('li.menu-item-has-children i').not(jQuery(this).parents('li').find('i')).addClass('fa-angle-down');
            jQuery(this).closest('li.menu-item-has-children').children('ul.sub-menu').slideToggle();
            jQuery(this).toggleClass('fa-angle-down fa-angle-up');
        });
    }
});

// Mobile menu Dropdown item js end

jQuery('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    navText: [
        "<i class='fa fa-caret-left'></i>",
        "<i class='fa fa-caret-right'></i>"
    ],
    autoplay: true,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
});

jQuery("html").niceScroll({
    cursorcolor: "#000000", // change cursor color in hex
    cursoropacitymin: 0, // change opacity when cursor is inactive (scrollabar "hidden" state), range from 1 to 0
    cursoropacitymax: 1, // change opacity when cursor is active (scrollabar "visible" state), range from 1 to 0
    cursorwidth: "5px", // cursor width in pixel (you can also write "5px")
    cursorborder: "1px solid #fff", // css definition for cursor border
    cursorborderradius: "5px", // border radius in pixel for cursor
    zindex: "auto", // change z-index for scrollbar div
    scrollspeed: 60, // scrolling speed
    mousescrollstep: 40, // scrolling speed with mouse wheel (pixel)
    touchbehavior: false, // enable cursor-drag scrolling like touch devices in desktop computer
    hwacceleration: true, // use hardware accelerated scroll when supported
    boxzoom: false, // enable zoom for box content
    dblclickzoom: true, // (only when boxzoom=true) zoom activated when double click on box
    gesturezoom: true, // (only when boxzoom=true and with touch devices) zoom activated when pinch out/in on box
    grabcursorenabled: true, // (only when touchbehavior=true) display "grab" icon
    autohidemode: true, // how hide the scrollbar works, possible values: 
    background: "", // change css for rail background
    iframeautoresize: true, // autoresize iframe on load event
    cursorminheight: 32, // set the minimum cursor height (pixel)
    preservenativescrolling: true, // you can scroll native scrollable areas with mouse, bubbling mouse wheel event
    railoffset: false, // you can add offset top/left for rail position
    bouncescroll: false, // (only hw accell) enable scroll bouncing at the end of content as mobile-like 
    spacebarenabled: true, // enable page down scrolling when space bar has pressed
    disableoutline: true, // for chrome browser, disable outline (orange highlight) when selecting a div with nicescroll
    horizrailenabled: true, // nicescroll can manage horizontal scroll
    railalign: "right", // alignment of vertical rail
    railvalign: "bottom", // alignment of horizontal rail
    enabletranslate3d: true, // nicescroll can use css translate to scroll content
    enablemousewheel: true, // nicescroll can manage mouse wheel events
    enablekeyboard: true, // nicescroll can manage keyboard events
    smoothscroll: true, // scroll with ease movement
    sensitiverail: true, // click on rail make a scroll
    enablemouselockapi: true, // can use mouse caption lock API (same issue on object dragging)
    cursorfixedheight: false, // set fixed height for cursor in pixel
    hidecursordelay: 400, // set the delay in microseconds to fading out scrollbars
    irectionlockdeadzone: 6, // dead zone in pixels for direction lock activation
    nativeparentscrolling: true, // detect bottom of content and let parent to scroll, as native scroll does
    enablescrollonselection: true, // enable auto-scrolling of content when selection text
    cursordragspeed: 0.3, // speed of selection when dragged with cursor
    rtlmode: "auto", // horizontal div scrolling starts at left side
    cursordragontouch: false, // drag cursor in touch / touchbehavior mode also
    oneaxismousemode: "auto", 
    scriptpath: "", // define custom path for boxmode icons ("" => same script path)
    preventmultitouchscrolling: true,// prevent scrolling on multitouch events
    disablemutationobserver: false,
  });