<?php
/*
Template Name: Simple Blog Listing
**/
remove_action('genesis_loop', 'genesis_do_loop');
// add_action('genesis_after_header', 'include_page');
function include_page() {
    $options = get_option( 'theme_sqt' );
    $blog_image = $options['blog_image'];
    ?>
    <div class="featured_image_area" style="background:url('<?= $blog_image; ?>');">
        <div class="header-title-outer">
          <div class="header-title">
            <div class="h1 entry-title" itemprop="headline">Blogs</div>
          </div>
        </div>
    </div>
<?php
}
add_action('genesis_loop', 'my_custom_loop');
function my_custom_loop() {
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $query_args = array('post_type' => 'post', 'posts_per_page' => 5, 'paged' => $paged, );
    $the_query = new WP_Query($query_args);
    if ($the_query->have_posts()) :
       $acount = 1;
       while ($the_query->have_posts()) : $the_query->the_post(); 
          $content = get_the_content();
          $content = preg_replace("/<img[^>]+\>/i", "", $content);          
          $content = apply_filters('the_content', $content);
          $content = str_replace(']]>', ']]>', $content);
          $content = apply_filters('the_content', $content);
          $content = wp_filter_nohtml_kses($content);
          $short_content = (strlen($content) > 150)?substr($content,0,150)."...":$content; 
          $post_title = get_the_title(); 
          $post_title = (strlen($post_title) > 32)?substr($post_title,0,32)."...":$post_title; 
          $post_image_title = get_the_title(); 
          
          $feat_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
          $image_url = $feat_image[0];
          
          if($image_url == "")
            $image_url = get_stylesheet_directory_uri()."/images/placeholder-blog.png";


          if($acount != 1){
            $image_url = bfi_thumb($image_url, array('width' => 300, 'height' => 200, 'crop' => true ));
          }
          else{
            $image_url = bfi_thumb($image_url, array('width' => 600, 'height' => 300, 'crop' => true ));
          }
        ?>
        <div class="news-item"> 
            <div class="single-post-blog"> 
                 <div class="row">  
                    <div class="col-md-4"> 
                        <div class="image-outer">
                            <a href="<?= get_permalink(); ?>" title="<?= get_the_title(); ?>"><img class="blog-image" src="<?php echo $image_url; ?>" title="<?php echo ucfirst(strtolower($post_image_title)); ?>" alt="<?php echo ucfirst(strtolower($post_image_title)); ?>"></a>
                        </div>
                    </div>
                    <div class="col-md-8">
                       <div class="blog-header">
                          <div class="blog-title"><a href="<?= get_permalink(); ?>" title="<?= get_the_title(); ?>"><?php echo ucfirst(strtolower($post_title)); ?></a></div>
                          <div class="blog-detail">
                              <div class="detail-date"><?php echo get_the_date('j M Y'); ?></div>
                          </div>
                       </div> 
                       <div class="blog-content">
                             <?php echo $short_content; ?>   
                       </div>
                       <div class="blog-link">
                          <a href="<?php  the_permalink(); ?>" title="Read More" class="readmore button">Read more &rarr;</a>
                       </div>
                    </div>
                </div>
            </div>
        </div>
       <?php $acount++; endwhile; ?>
        
        <?php if (function_exists("pagination")) {
                pagination($the_query->max_num_pages);}  ?>
        <?php wp_reset_postdata(); ?>

     <?php else: ?>
        <p class="no-post-data"><?php _e('Sorry, no posts matched your criteria.'); ?></p>
    <?php
    endif;
}
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_action('genesis_after_content','sidebar_area');
function sidebar_area(){
?>
<aside class="widget widget-area">
    <h3 class="widget-title">Recent Posts</h3>
    <div class="cms-recent-post">
        <div class="cms-recent-post-wrapper">
          <?php
           $args = array('post_type' => 'post', 'post_status' => 'publish','posts_per_page' => '5', 'orderby' => 'date', 'order' => 'DESC');
           $blog_list = new WP_Query($args);
            while ($blog_list->have_posts()) : $blog_list->the_post();
                $sidebar_post_title = get_the_title(); 
                $sidebar_post_title = (strlen($sidebar_post_title) > 28)?substr($sidebar_post_title,0,28)."...":$sidebar_post_title;
              
                $feat_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'thumbnail' );
                $image_url = $feat_image[0];
                if(empty($image_url))
                  $image_url = get_stylesheet_directory_uri()."/images/thumbnail-placeholder-blog.png";
              ?>
            <div class="widget-recent-item clearfix">
                <div class="image-thumbnail">
                    <a class="img" href="<?php the_permalink(); ?>"><img class="thumbnail-image" src="<?php echo $image_url; ?>" title="<?php echo ucfirst(strtolower(get_the_title())); ?>" alt="<?php echo ucfirst(strtolower(get_the_title())); ?>"></a>
                </div>
                <div class="image-main">
                    <h4><a href="<?php the_permalink(); ?>" title="<?php echo ucfirst(strtolower(get_the_title())); ?>"><?php  echo ucfirst(strtolower($sidebar_post_title)); ?></a></h4>
                    
                </div>
            </div>
          <?php endwhile ?>
        </div>
    </div>
</aside>
<?php
}
genesis();