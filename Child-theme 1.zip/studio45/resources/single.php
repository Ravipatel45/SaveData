<?php
remove_action('genesis_entry_header', 'genesis_entry_header_markup_open', 5);
remove_action('genesis_entry_header', 'genesis_entry_header_markup_close', 15);
remove_action('genesis_entry_header', 'genesis_post_info', 12);
remove_action('genesis_entry_footer', 'genesis_post_meta');
//remove_action('genesis_entry_header', 'genesis_do_post_title');
// add_action("genesis_after_header", "feature_image_for_post_mm");
function feature_image_for_post_mm() {
    global $post;
    $single_featured_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
    ?>
    <div class="featured_image_area" style="background:url('<?= $single_featured_image; ?>');">
        <div class="header-title-outer">
          <div class="header-title">
            <div class="h1 entry-title" itemprop="headline"><?= get_the_title(); ?></div>
          </div>
        </div>
    </div>
<?php
}
//add_action("genesis_entry_header", "add_feature_image");
function add_feature_image() {
    ?>
    sadasd
    <div class="head_title">
        <h1 class="gallery_heading"> <?php echo get_the_title(); ?></h1>
    </div>
    <?php if (has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('large'); ?>
    <?php endif; ?>
    <?php
}
remove_action('genesis_loop', 'genesis_do_loop');
add_action('genesis_loop', 'my_custom_loop');
function my_custom_loop() {
    global $post;
    ?>
    <section class="main_content_area location_section">
        <div class="cntnt_cs right_cs">
            <div class="feature_cs">
                <?php
                $my_postid = $post->ID; //This is page id or post id
                $content_post = get_post($my_postid);
                $content = $content_post->post_content;
                $content = apply_filters('the_content', $content);
                $content = str_replace(']]>', ']]&gt;', $content);
                $service_featured_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
                    
                if ($service_featured_image) {
                    $home_image_src = bfi_thumb($service_featured_image['0'], array(
                        'width' => 600,
                        'height' => 200,
                        'crop' => true
                    ));
                    ?>
                    <div class="feature_cs">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php echo $home_image_src; ?>" alt="<?php the_title_attribute(); ?>" title="<?php the_title_attribute(); ?>">
                        </a>
                    </div>            
    <?php } ?>    
            </div>
            <div class="date_news">
                <span class="date1"><?= get_the_date("j") ?></span>
                <span class="date2"><?= get_the_date("M") ?></span>
                <span class="date3"><?= get_the_date("Y") ?></span>
            </div>
            <div class="containt_news">
                <h3><?php the_title(); ?></h3>
                <div class="content"><?php echo $content; ?> </div>
            </div>
        </div>
    </section>
    <?php
}
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_action('genesis_after_content','sidebar_area');
function sidebar_area(){
?>
<aside class="widget widget-area">
    <h3 class="widget-title">Recent Posts</h3>
    <div class="cms-recent-post">
        <div class="cms-recent-post-wrapper">
          <?php
           $args = array('post_type' => 'post', 'post_status' => 'publish','posts_per_page' => '5', 'orderby' => 'date', 'order' => 'DESC');
           $blog_list = new WP_Query($args);
            while ($blog_list->have_posts()) : $blog_list->the_post();
                $sidebar_post_title = get_the_title(); 
                $sidebar_post_title = (strlen($sidebar_post_title) > 28)?substr($sidebar_post_title,0,28)."...":$sidebar_post_title;
              
                $feat_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'thumbnail' );
                $image_url = $feat_image[0];
                if(empty($image_url))
                  $image_url = get_stylesheet_directory_uri()."/images/thumbnail-placeholder-blog.png";
              ?>
            <div class="widget-recent-item clearfix">
                <div class="image-thumbnail">
                    <a class="img" href="<?php the_permalink(); ?>"><img class="thumbnail-image" src="<?php echo $image_url; ?>" title="<?php echo ucfirst(strtolower(get_the_title())); ?>" alt="<?php echo ucfirst(strtolower(get_the_title())); ?>"></a>
                </div>
                <div class="image-main">
                    <h4><a href="<?php the_permalink(); ?>" title="<?php echo ucfirst(strtolower(get_the_title())); ?>"><?php  echo ucfirst(strtolower($sidebar_post_title)); ?></a></h4>
                    
                </div>
            </div>
          <?php endwhile ?>
        </div>
    </div>
</aside>
<?php
}
remove_action('genesis_sidebar_alt', 'genesis_do_sidebar_alt');
genesis();
?>.



 <div class="item">
            <div class="slider-content">
                <p class="main-title"><?php echo $title; ?></p>
                <p class="sub-title"><?php echo $event_date; ?></p>
                <p class="yelow-title"><?php echo $event_time; ?></p>
                <p class="slider-img"><img src="<?php echo $image; ?>"></p>
                <p class="slide-title"><?php echo $event_content; ?></p>
                <p class="book-btn"><a href="javascript:void(0);" data-toggle="modal" data-target="#booknowmodal">Book a Table</a></p>
                <p class="see-menus"><a href="<?php echo $book_title_button; ?>">See Menus</a></p>
            </div>
        </div>